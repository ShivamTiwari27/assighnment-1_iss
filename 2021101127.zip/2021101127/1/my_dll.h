#include"node.h"
#include<stdio.h>
#include<stdlib.h>

typedef struct my_dll {     

    int size;
    struct node *root  ;

} My_dll ;


void insert ( My_dll *list  ,int x); 

void insert_at (My_dll *list ,int x,int i);

void delete_ ( My_dll *list , int i);

int find ( My_dll *list , int x);

void prune (My_dll *list );

void print (My_dll *list );

void print_reverse (My_dll *list );

int get_size (My_dll *list );
