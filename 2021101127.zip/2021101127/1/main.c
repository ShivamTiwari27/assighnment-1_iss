#include <stdio.h>
#include <string.h>
#include "my_dll.h"
#include "node.h"

int main()
{

    My_dll *list = (My_dll *)malloc(sizeof(My_dll));

    list->root = NULL;
    list->size = 0;

    char ch[20];

    while (1)
    {
        scanf("%s", ch);

        if (strcmp(ch, "insert") == 0)
        {
            int x;
            scanf("%d", &x);
            insert(list, x);
        }

        else if (strcmp(ch, "insert_at") == 0)
        {
            int m, n;
            scanf("%d %d", &m, &n);
            insert_at(list, m, n);
        }
        else if (strcmp(ch, "delete_") == 0)
        {
            int i;
            scanf("%d", &i);
            delete_(list, i);
        }

        else if (strcmp(ch, "find") == 0)
        {
            int x,y;
            scanf("%d", &x);
            y=find(list, x);
            printf("%d\n",y);
        }

        else if (strcmp(ch, "prune") == 0)
        {
            prune(list);
        }

        else if (strcmp(ch, "print") == 0)
        {
            print(list);
        }

        else if (strcmp(ch, "print_reverse") == 0)
        {
            print_reverse(list);
        }

        else if (strcmp(ch, "getsize") == 0)
        {
            int x=get_size(list);
              printf("%d\n",x);

        }
    }

    return 0;
}