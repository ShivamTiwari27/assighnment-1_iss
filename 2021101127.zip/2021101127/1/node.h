#ifndef __Node 
#define __Node

typedef struct node{

    int data;
    struct node* prev ;
    struct node* next ;

} Node;

#endif