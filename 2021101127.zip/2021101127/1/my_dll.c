#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "my_dll.h"
#include "node.h"

void insert(My_dll *list, int x)
{

    struct node *New_node = NULL;
    struct node *temp = list->root;
    New_node = (Node *)malloc(sizeof(Node));
    assert(New_node != NULL);

    New_node->data = x;

    if (list->root == NULL)
    {
        list->root = New_node;
        New_node->prev = NULL;
        New_node->next = NULL;
        list->size++;
        return;
    }

    while (temp->next != NULL)
        temp = temp->next;

    New_node->prev = temp;
    New_node->next = NULL;
    temp->next = New_node;
    list->size++;

    return;
}

void insert_at(My_dll *list, int x, int i)
{

    struct node *New_node = NULL;
    struct node *temp = list->root;
    New_node = (Node *)malloc(sizeof(Node));
    assert(New_node != NULL);

    New_node->data = x;

    if (i == 0)
    {
        New_node->prev = NULL;
        New_node->next = temp;
        temp->prev = New_node;
        list->root=New_node;
        
        list->size++;
        return;
    }


    int k = 0;
    while (k < i-1)
    {
        temp = temp->next;
        k++;
    }

    if (i == list->size)
    {
        // temp = temp->prev;
        New_node->prev = temp;
        New_node->next = NULL;
        temp->next = New_node;
        list->size++;
        return;
    }
    temp=temp->next;
    New_node->next = temp;
    New_node->prev = temp->prev;
    temp->prev->next = New_node;
    temp->prev = New_node;
    list->size++;

    return;
}

void delete_(My_dll *list, int i)
{
    struct node *temp = list->root;

    if (i == 0)
    {
        list->root = temp->next;
        temp->next->prev = NULL;
        list->size-- ;
        return;
    }
    if (i == list->size - 1)
    {
        while (temp->next != NULL)
            temp = temp->next;

        temp = temp->prev;
        temp->next = NULL;
        list->size-- ;
        return;
    }

    for (int s = 0; s < i; s++)
        temp = temp->next;

    temp->prev->next = temp->next;
    temp->next->prev = temp->prev;
    list->size-- ;

    return;
}

int find(My_dll *list, int x)
{
    struct node *temp = list->root;
    int k = 0;
    while (temp->data != x)
    {
        k++;
        temp=temp->next;
        if (temp->next == NULL)
            return -1;
    }

    return k;
}

void prune(My_dll *list)
{
    int k = 0;
    struct node *temp = list->root;
    while (temp != NULL)
    {
        if(temp->next==NULL && k%2!=0)
        {
            temp= temp->prev;
            temp->next=NULL;
            list->size-- ;
            return;
        }


        if (k % 2 != 0)
        {

            temp->prev->next = temp->next;
            temp->next->prev = temp->prev;
            list->size--;
        }
        temp = temp->next;
        k++;
    }

    return;
}

void print(My_dll *list)
{
    struct node *temp = list->root;
    while (temp != NULL)
    {
        printf("%d\n", temp->data);
        temp = temp->next;
    }
    return;
}

/*void print(My_dll list)
{
    for(struct node* temp= list ;temp!=NULL ;temp=temp->next)
        printf("%d\n",temp->data);
}*/

void print_reverse(My_dll *list)
{
    struct node *temp = list->root;
    while (temp ->next!= NULL)
        temp = temp->next;

    while (temp != NULL)
    {
        printf("%d\n", temp->data);
        temp = temp->prev;
    }
    return;
}

int get_size(My_dll *list)
{
  
    return list->size;
}