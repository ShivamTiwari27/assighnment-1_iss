#ifndef _COMPLEX_
#define _COMPLEX_

typedef struct Complex
{

    int n; // n is the no. of dimension in the complex no
    double *dimension;
} complex;

complex add(complex a, complex b);
complex sub(complex a, complex b);
float mod(complex a);
float dot(complex a, complex b);
float Cos(complex a, complex b);

#endif
