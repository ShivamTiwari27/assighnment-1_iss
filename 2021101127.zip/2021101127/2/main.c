#include <stdio.h>
#include "complex.h"
#include <string.h>
#include <stdlib.h>

int main()

{
    char ch[20];
    int N;
    scanf("%s", ch);
    scanf("%d", &N);
    complex a;
    complex b;
    complex c;
    a.dimension = (double *)malloc(N * sizeof(double));
    b.dimension = (double *)malloc(N * sizeof(double));
    a.n = N;
    b.n = N;
    float ans;

    if (strcmp(ch, "ADD") == 0)
    {
        for (int i = 0; i < N; i++)
            scanf("%lf", &a.dimension[i]);

        for (int i = 0; i < N; i++)
            scanf("%lf", &b.dimension[i]);
        c = add(a, b);
        for (int i = 0; i < N; i++)
            printf("%lf ", c.dimension[i]);

        printf("\n");
    }

    else if (strcmp(ch, "SUB") == 0)
    {
        for (int i = 0; i < N; i++)
            scanf("%lf", &a.dimension[i]);

        for (int i = 0; i < N; i++)
            scanf("%lf", &b.dimension[i]);
        c = sub(a, b);

        for (int i = 0; i < N; i++)
            printf("%lf ", c.dimension[i]);
        printf("\n");
    }
    else if (strcmp(ch, "MOD") == 0)
    {

        for (int i = 0; i < N; i++)
            scanf("%lf", &a.dimension[i]);

        ans = mod(a);

        printf("%.2f\n", ans);
    }
    else if (strcmp(ch, "DOT") == 0)
    {
        for (int i = 0; i < N; i++)
            scanf("%lf", &a.dimension[i]);

        for (int i = 0; i < N; i++)
            scanf("%lf", &b.dimension[i]);
        ans = dot(a, b);

        printf("%.2f\n", ans);
    }
    else if (strcmp(ch, "COS") == 0)
    {
        for (int i = 0; i < N; i++)
            scanf("%lf", &a.dimension[i]);

        for (int i = 0; i < N; i++)
            scanf("%lf", &b.dimension[i]);
        ans = Cos(a, b);

        printf("%f\n", ans);
    }

    return 0;
}