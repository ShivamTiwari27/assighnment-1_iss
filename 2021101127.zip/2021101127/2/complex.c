#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "complex.h"

complex add(complex a, complex b)
{
    int Dimen = a.n;
    complex c;
    c.dimension = (double *)malloc(Dimen * sizeof(double));
    c.n = Dimen;
    for (int i = 0; i < Dimen; i++)
    {
        c.dimension[i] = a.dimension[i] + b.dimension[i];
    }
    return c;
}

complex sub(complex a, complex b)
{
    int Dimen = a.n;
    complex c;
    c.dimension = (double *)malloc(Dimen * sizeof(double));
    c.n = Dimen;

    for (int i = 0; i < Dimen; i++)
    {
        c.dimension[i] = a.dimension[i] - b.dimension[i];
    }
    return c;
}

float mod(complex a)
{
    float sum = 0, Dimen = a.n;
    complex c;
    c.dimension = (double *)malloc(Dimen * sizeof(double));
    c.n = Dimen;

    for (int i = 0; i < Dimen; i++)
    {
        sum += a.dimension[i] * a.dimension[i];
    }
    sum=sqrt(sum);
    return sum;
}

float dot(complex a, complex b)
{
    int sum = 0, Dimen = a.n;
    complex c;

    c.dimension = (double *)malloc(Dimen * sizeof(double));
    c.n = Dimen;

    for (int i = 0; i < Dimen; i++)
        sum += a.dimension[i] * b.dimension[i];

    return sum;
}

float Cos(complex a, complex b)
{
    int Dimen = a.n;
    complex c;

    c.dimension = (double *)malloc(Dimen * sizeof(double));
    c.n = Dimen;

    float x, y;

    x = dot(a, b);

    y = mod(a) * mod(b);

    float z = x / y;

    return z;
}