#!/bin/bash
echo "for 1st part A"
grep . quotes.txt
echo
echo "for first part B"
cat -n quotes.txt | sort -uk2 | sort -n | cut -f2-
