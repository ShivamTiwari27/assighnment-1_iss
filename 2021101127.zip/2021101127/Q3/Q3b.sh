#!/bin/bash
wc -l < $1