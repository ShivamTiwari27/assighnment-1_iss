#!/bin/bash
wc -c < $1