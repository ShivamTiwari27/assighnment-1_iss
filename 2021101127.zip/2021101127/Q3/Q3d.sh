#!/bin/bash
IFS=$'\n'
n=1
while read line;
do
a=$(wc -w <<< "$line")
echo "Line No:<$n> - Count of Words:[$a]"
n=$((n+1))
done < $1