#include"song.h"
#ifndef __MUSICPLAYER
#define __MUSICPLAYER

typedef struct Musicplayer{
    song* queue_head;
    song* curr_song;
}musicplayer;


musicplayer *createMusicPlayer (void);
int addSongToQueue (musicplayer* Music, song* S);
int removeSongFromQueue (musicplayer* Music , int N); 
int playSong (musicplayer* Music);
song* getCurrentSong (musicplayer* Music);


#endif