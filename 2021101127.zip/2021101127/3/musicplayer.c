#include <stdio.h>
#include <stdlib.h>
#include "musicplayer.h"
#include "song.h"

musicplayer *createMusicPlayer(void)
{
    musicplayer *user = malloc(sizeof(musicplayer));
    user->curr_song = NULL;
    user->queue_head = NULL;

    return user;
}

int addSongToQueue(musicplayer *Music, song *S)
{
    if (Music->queue_head == NULL)
    {
        Music->queue_head = S;
        S->next = NULL;
        return 0;
    }
    song *curr_song = Music->queue_head;
    while (curr_song->next != NULL)
    {
        curr_song = curr_song->next;
    }
    curr_song->next = S;
    return 0;
}

int sizeofqueue(musicplayer *Music)
{
    int size = 0;
    song *curr_song = Music->queue_head;

    while (curr_song != NULL)
    {
        curr_song = curr_song->next;
        size += 1;
    }
    return size;
}

int removeSongFromQueue(musicplayer *Music, int N)
{
    int size = sizeofqueue(Music);
    if (size == 0)
        return 1;

    if (N == 0)
    {
        if (size == 1)
        {
            Music->queue_head = NULL;
            return 0;
        }

        Music->queue_head = Music->queue_head->next;
        return 0;
    }
    song *curr_song = Music->queue_head;
    song *psong = NULL;

    for (int i = 0; i < N; i++)
    {
        psong = curr_song;
        curr_song = curr_song->next;
    }

    if (N == size - 1)
    {
        psong->next = NULL;
        return 0;
    }

    psong->next = curr_song->next;
    return 0;
}

int playSong(musicplayer *Music)
{
    if (Music->queue_head == NULL)
        return 1;

    song *curr_song = Music->queue_head;
    if (curr_song->next == NULL)
    {
        Music->curr_song = curr_song;
        Music->queue_head = NULL;
        return 0;
    }
    Music->curr_song = Music->queue_head;
    Music->queue_head = Music->queue_head->next;
    return 0;
}

song *getCurrentSong(musicplayer *Music)
{
    return (Music->curr_song);
}
