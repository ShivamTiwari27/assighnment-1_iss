#ifndef __SONG
#define __SONG

typedef struct Song{

    char *name;
    char *Artist;
    float duration;
    struct Song* next;
}song;
song* makeSong (char*name  , char *Artist , float duration);

#endif

