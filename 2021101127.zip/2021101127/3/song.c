#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"song.h"

song* makeSong(char *name,char *Artist,float duration)
{
    song* temp=(song*)malloc(sizeof(song));
    temp->name=(char*)malloc(sizeof(strlen(name))+1);
    temp->Artist=(char*)malloc(sizeof(strlen(Artist))+1);

    strcpy(temp->name,name);
    strcpy(temp->Artist,Artist);
    temp->duration=duration;
    return temp;
}