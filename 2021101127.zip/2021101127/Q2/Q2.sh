#!/bin/bash
grep . quotes.txt > temp.txt
awk -F "~" '{print $2 "  once  said,  \""  $1 "\""}' temp.txt < speech.txt