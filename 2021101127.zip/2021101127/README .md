
# DSA Assignment 1

All the programs were compiled and run on Linux OS.


### Q1.


$ cd <destination of main.c and my_dll.c>
$ gcc main.c my_dll.c
$ ./a.out

** After successful compilation and execution a file will be generated at 
<destination of main.c and my_dll.c> . Use "quit" to exit the driver terminal.

### Q2.
$ cd <destination of main.c and complex.c>
$ gcc main.c complex.c
$ ./a.out

** After successful compilation and execution a file will be generated at 
<destination of main.c and complex.c>

### Q3

$ cd <destination of main.c and musicplayer.c >
$ gcc main.c musicplayer.c song.c
$ ./a.out

** After successful compilation and execution a file will be generated at 
<destination of main.c and musicplayer.c>


